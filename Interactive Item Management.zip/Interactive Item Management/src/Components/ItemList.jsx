import React, { useState, useEffect } from 'react';
import './ItemList.css';

function ItemList() {
  const [items, setItems] = useState([]);
  const [id, setId] = useState(1);
  const [name, setName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    // Simulate data fetching from an API
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => console.log('Fetched data:', data));
  };

  const handleFormSubmit = event => {
    event.preventDefault();
    const newItem = { id, name };
    setItems([...items, newItem]);
    setId(id + 1);
    setName('');
  };

  const handleSearchInputChange = event => {
    setSearchQuery(event.target.value);
  };

  const filteredItems = items.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          value={name}
          onChange={e => setName(e.target.value)}
          placeholder="Enter item name"
        />
        <button type="submit">Add Item</button>
      </form>
      <input
        type="text"
        value={searchQuery}
        onChange={handleSearchInputChange}
        placeholder="Search items"
      />
      <ul>
        {filteredItems.map(item => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default ItemList;
